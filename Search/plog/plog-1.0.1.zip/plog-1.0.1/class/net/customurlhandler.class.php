<?php


	include_once( PLOG_CLASS_PATH."class/object/object.class.php" );
	include_once( PLOG_CLASS_PATH."class/config/config.class.php" );
	include_once( PLOG_CLASS_PATH."class/net/linkformatmatcher.class.php" );
    include_once( PLOG_CLASS_PATH."class/net/url.class.php" );	

	/**
	 * \ingroup Net
	 *
	 * Parses incoming URLs when "custom URLs" are enabled. It uses the LinkFormatMatcher
	 * to determine which *_link_format configuration setting matches the incoming URL, extracts
	 * the information from the URL according to the specified format and puts it back to the
	 * request so that the core classes can fetch the parameters.
	 *
	 * The use of this class is very specific and it should not be be called directly anyway.
	 *
	 * @see LinkFormatMatcher
	 */	
	class CustomUrlHandler extends Object
	{
	
		var $_formats;
		var $_params;
		var $_vars;
		var $_includeFile;
		var $_format;
        var $_indexName;
	
		function CustomUrlHandler()
		{
			$this->Object();
			
			// we need to figure out the full server path so that we can generate proper
			// regexps for the url parsing. This should get rid of issues like
			// http://bugs.plogworld.net/view.php?id=369
			// The base url will be one or another depending
            $config =& Config::getConfig();
            if( $config->getValue( "subdomains_enabled" ))
                $url = new Url( $config->getValue( "subdomains_base_url" ));
            else
                $url = new Url( $config->getValue( "base_url" ));
            $path = $url->getPath();
			
			// intialize the array we're going to use
			$config =& Config::getConfig();
            $this->_indexName = $config->getValue("script_name");
			$this->_formats = Array( "permalink_format" => $path.$config->getValue( "permalink_format" ),
									 "category_link_format" => $path.$config->getValue( "category_link_format" ),
									 "blog_link_format" => $path.$config->getValue( "blog_link_format" ),
									 "archive_link_format" => $path.$config->getValue( "archive_link_format" ),
									 "user_posts_link_format" => $path.$config->getValue( "user_posts_link_format" ),
									 "post_trackbacks_link_format" => $path.$config->getValue( "post_trackbacks_link_format" ),
									 "template_link_format" => $path.$config->getValue( "template_link_format" ),
									 "album_link_format" => $path.$config->getValue( "album_link_format" ),
									 "resource_link_format" => $path.$config->getValue( "resource_link_format" ),
									 "resource_download_link_format" => $path.$config->getValue( "resource_download_link_format" ),
									 "resource_preview_link_format" => $path.$config->getValue( "resource_preview_link_format" ),
									 "resource_medium_size_preview_link_format" => $path.$config->getValue( "resource_medium_size_preview_link_format" ));
			
			// if the url did not match any of the current settings, then let's try to parse it as an old
			// "search engine friendly" url
			$this->_fallback = Array( "permalink_format" => "/post/{blogid}/{postid}",
									 "category_link_format" => "/category/{$blogid}/{postid}",
									 "blog_link_format" => "/blogid}",
									 "archive_link_format" => "/archives/{blogid}/{year}/{month}/{day}",
									 "user_posts_link_format" => "/user/{blogid}/{userid}",
									 "post_trackbacks_link_format" => "/trackbacks/{blogid}/{postid}",
									 "template_link_format" => "/static/{blogid}/{templatename}",
									 "album_link_format" => "/album/{blogid}/{albumid}",
									 "resource_link_format" => "/resource/{blogid}/{resourceid}",
									 "resource_download_link_format" => "/get/{blogid}/{resourceid}",
									 "resource_preview_link_format" => "",  // this one does not exist
									 "resource_medium_size_preview_link_format" => "" ); // this one does not exist either
		}
		
		function process( $requestUri )
		{
			// decode the string, since it seems that php will not do it for us in this case...
			$requestUri = urldecode( $requestUri);
			
	        // we should remove anything that comes after a '?' parameter, since we don't want to take
	        // HTTP GET parameters into account                        
            if(( $pos = strpos( $requestUri, '?' ))) {
	            // if so, remove everything including the question mark
	            $requestUri = substr( $requestUri, 0, $pos );
            }
                  
			// guess which format we're using...
			$m = new LinkFormatMatcher( $requestUri, $this->_formats );
			$this->_format = $m->identify();
			$this->_params = $m->getParameters();
			
			// if it didn't work out the first time, let's try with an additional url format
			if( !$this->_fillRequestParameters()) {
				$m = new LinkFormatMatcher( $requestUri, $this->_fallback );
				$this->_format = $m->identify();
				$this->_params = $m->getParameters();
				$this->_fillRequestParameters();
			}
			
			return( true );
		}
		
		/**
		 * @private
		 */
		function _fillRequestParameters()
		{
			// ...and then based on this, fill in the parameters in the request
			$matched = true;
			if( $this->_format == "permalink_format" ) {
				$this->_includeFile = $this->_indexName;
				$this->_params["date"] = $this->_params["year"].$this->_params["month"].$this->_params["day"].$this->_params["hours"].$this->_params["minutes"];
				$this->_params["op"] = "ViewArticle";
				$this->_vars = Array( "postid" => "articleId",
							   "postname" => "articleName",
							   "blogid" => "blogId",
							   "blogname" => "blogName",
							   "userid" => "userId",
							   "username" => "userName",
							   "catid" => "postCategoryId",
							   "catname" => "postCategoryName",
							   "date" => "Date",
							   "blogowner" => "blogUserName" );
			}
			elseif( $this->_format == "blog_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["op"] = "Default";
				$this->_vars = Array( "blogid" => "blogId",
							          "blogname" => "blogName",
									  "blogowner" => "blogUserName" );
			}
			elseif( $this->_format == "category_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["op"] = "Default";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "catid" => "postCategoryId",
							   "catname" => "postCategoryName" );
			}
			elseif( $this->_format == "archive_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["date"] = $this->_params["year"].$this->_params["month"].$this->_params["day"].$this->_params["hours"].$this->_params["minutes"];
				$this->_params["op"] = "Default";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "date" => "Date" );
			}
			elseif( $this->_format == "user_posts_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["date"] = $this->_params["year"].$this->_params["month"].$this->_params["day"].$this->_params["hours"].$this->_params["minutes"];
				$this->_params["op"] = "Default";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "date" => "Date",
							   "userid" => "userId",
							   "catid" => "postCategoryId",
							   "catname" => "postCategoryName",
							   "username" => "userName" );
			}
			elseif( $this->_format == "post_trackbacks_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["op"] = "Trackbacks";
				$this->_params["date"] = $this->_params["year"].$this->_params["month"].$this->_params["day"].$this->_params["hours"].$this->_params["minutes"];		
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "postid" => "articleId",
							   "postname" => "articleName",
							   "userid" => "userId",
							   "username" => "userName",
							   "catid" => "postCategoryId",
							   "catname" => "postCategoryName",
							   "date" => "Date" );					   
			}
			elseif( $this->_format == "template_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["op"] = "Template";
				$this->_vars = Array( "templatename" => "show",
							   "blogid" => "blogId",
							   "blogowner" => "blogUserName",							   
							   "blogname" => "blogName" );
			}
			elseif( $this->_format == "album_link_format" ) {
				$this->_includeFile = $this->_indexName;	
				$this->_params["op"] = "ViewAlbum";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "albumid" => "albumId",
							   "blogowner" => "blogUserName",							   
							   "albumname" => "albumName" );
			}
			elseif( $this->_format == "resource_link_format" ) {
				$this->_includeFile = $this->_indexName;
				$this->_params["op"] = "ViewResource";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "albumid" => "albumId",
							   "albumname" => "albumName",
							   "resourceid" => "resId",
							   "resourcename" => "resource" );
			}
			elseif( $this->_format == "resource_download_link_format" ) {
				$this->_includeFile = "resserver.php";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "albumid" => "albumId",
							   "albumname" => "albumName",
							   "resourceid" => "resId",
							   "resourcename" => "resource" );
			}
			elseif( $this->_format == "resource_preview_link_format" ) {
				$this->_includeFile = "resserver.php";
				$this->_params["mode"] = "preview";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "albumid" => "albumId",
							   "albumname" => "albumName",
							   "resourceid" => "resId",
							   "resourcename" => "resource",
							   "mode" => "mode");
			}
			elseif( $this->_format == "resource_medium_size_preview_link_format" ) {
				$this->_includeFile = "resserver.php";
				$this->_params["mode"] = "medium";
				$this->_vars = Array( "blogid" => "blogId",
							   "blogname" => "blogName",
							   "blogowner" => "blogUserName",							   
							   "albumid" => "albumId",
							   "albumname" => "albumName",
							   "resourceid" => "resId",
							   "resourcename" => "resource",
							   "mode" => "mode");			
			}
			else {
				$this->_includeFile = $this->_indexName;
				$matched = false;
			}
			
			return( $matched );
		}
		
		function getVars()
		{
			return $this->_vars;
		}
		
		function getParams()
		{
			return $this->_params;
		}
		
		function getIncludeFile()
		{
			return $this->_includeFile;
		}
	}
?>