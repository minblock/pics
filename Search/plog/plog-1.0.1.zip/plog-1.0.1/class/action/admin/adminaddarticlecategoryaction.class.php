<?php

	include_once( PLOG_CLASS_PATH."class/action/admin/adminaction.class.php" );
    include_once( PLOG_CLASS_PATH."class/dao/articlecategories.class.php" );
    include_once( PLOG_CLASS_PATH."class/dao/articlecategory.class.php" );
    include_once( PLOG_CLASS_PATH."class/data/validator/stringvalidator.class.php" );
    include_once( PLOG_CLASS_PATH."class/data/validator/emptyvalidator.class.php" );
	include_once( PLOG_CLASS_PATH."class/data/textfilter.class.php" );	
	include_once( PLOG_CLASS_PATH."class/view/admin/adminarticlecategorieslistview.class.php" );

    /**
     * \ingroup Action
     * @private
     *
     * Action that adds a new article category to the database.
     */
    class AdminAddArticleCategoryAction extends AdminAction 
	{

    	var $_categoryName;
        var $_categoryUrl;
		var $_properties;
		var $_categoryDescription;

    	/**
         * Constructor. If nothing else, it also has to call the constructor of the parent
         * class, BlogAction with the same parameters
         */
        function AdminAddArticleCategoryAction( $actionInfo, $request )
        {
        	$this->AdminAction( $actionInfo, $request );
			
			// register two validators
			$this->registerFieldValidator( "categoryName", new StringValidator());
			$this->registerFieldValidator( "categoryDescription", new StringValidator());
			$this->registerFieldValidator( "categoryInMainPage", new EmptyValidator());
			// and the view we should show in case there is a validation error
			$errorView = new AdminTemplatedView( $this->_blogInfo, "newpostcategory" );
			$errorView->setErrorMessage( $this->_locale->tr("error_adding_article_category" ));			
			$this->setValidationErrorView( $errorView );

        }

        /**
         * Carries out the specified action
         */
        function perform()
        {
			// fetch the data, we already know it's valid and that we can trust it!
        	$this->_categoryName     = $this->_request->getValue( "categoryName" );
            $this->_categoryUrl      = $this->_request->getValue( "categoryUrl" );
            $this->_categoryInMainPage = Textfilter::checkboxToBoolean($this->_request->getValue( "categoryInMainPage" ));
			$this->_categoryDescription = $this->_request->getValue( "categoryDescription" );
			$this->_properties = $this->_request->getValue( "properties" );		
		
			// create the object...
            $categories = new ArticleCategories();
            $category   = new ArticleCategory( $this->_categoryName,
                                               $this->_categoryUrl,
                                               $this->_blogInfo->getId(),
                                               $this->_categoryInMainPage,
											   $this->_categoryDescription,
											   0,
											   $this->_properties );
											   
			// fire the pre event...
			$this->notifyEvent( EVENT_PRE_CATEGORY_ADD, Array( "category" => &$category ));

            // once we have built the object, we can add it to the database!
            if( $categories->addArticleCategory( $category )) {
				// if everything went fine, transfer the execution flow to the action that
				// lists all the article categories... without forgetting that we should let the
				// next class know that we actually added a category alongside a message
				// and the category that we just added!
				$this->_view = new AdminArticleCategoriesListView( $this->_blogInfo );
				$this->_view->setSuccess( true );
				$this->_view->setSuccessMessage( $this->_locale->pr("category_added_ok", $category->getName()));
				
				// fire the post event
				$this->notifyEvent( EVENT_POST_CATEGORY_ADD, Array( "category" => &$category ));
				
				// clear the cache if everything went fine
				CacheControl::resetBlogCache( $this->_blogInfo->getId(), false );														
				
				$this->setCommonData();				
            }
            else {
				// if there was an error, we should say so... as well as not changing the view since
				// we're going back to the original view where we can add the category
				$this->_view->setError( true );
				$this->_view->setErrorMessage( $this->_locale->tr("error_adding_article_category" ));
				$this->setCommonData( true );
            }

            // better to return true if everything fine
            return true;
        }
    }
?>